package com.example.app2; // استبدل اسم الحزمة بما يناسب مشروعك

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // إخفاء شريط التطبيق العلوي لتظهر الشاشة بالكامل
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }
}